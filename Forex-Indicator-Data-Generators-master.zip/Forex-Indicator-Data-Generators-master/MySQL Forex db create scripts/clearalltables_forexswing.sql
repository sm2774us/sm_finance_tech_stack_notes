use forexswing;
-----------------

truncate table audusd;
truncate table audusd60;
truncate table audusd1440;
truncate table eurusd;
truncate table eurusd60;
truncate table eurusd1440;
truncate table gbpusd;
truncate table gbpusd60;
truncate table gbpusd1440;
truncate table nzdusd;
truncate table nzdusd60;
truncate table nzdusd1440;
